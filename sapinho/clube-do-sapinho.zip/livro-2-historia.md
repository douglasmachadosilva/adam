# Froguinho e o Grande Prêmio do Mundo Lá Fora

## Capítulo 1 — A Pedra foi promovida

Naquela manhã, {nome} encontrou uma coisa muito estranha.

A Pedra estava ocupada.

Em cima dela havia duas patas da frente, duas patas de trás e um sapinho com cara de quem tinha comprado o lugar.

— Froguinho?! Você subiu sozinho?

— Subi. O elevador estava quebrado.

— Não tem elevador.

— Isso explica muita coisa.

{nome} se aproximou para observar, sem assustar o amigo.

Até pouco tempo atrás, Froguinho nadava usando uma cauda comprida. Agora a cauda era só um restinho. Seu corpo a estava absorvendo, reaproveitando seus materiais.

E ele tinha saltado para fora da água.

Sozinho.

{nome} abriu um sorriso enorme.

— Você conseguiu!

Froguinho estufou o peito.

— Gostaria de agradecer às minhas quatro patas. Principalmente àquela ali.

Olhou para a pata esquerda.

— Ela acreditou em mim.

A pata não respondeu.

Muito profissional.

— E à Pedra — continuou ele. — Que será promovida.

— Promovida a quê?

— Pedra do Andar de Cima.

{nome} riu.

Froguinho olhou ao redor. Havia luz, sombras e um movimento de folhas perto da janela.

— Ei… O mundo continua depois daquela parede?

— Continua.

— Bastante?

— Bastante.

Froguinho ficou quieto por um instante.

Depois cochichou para a Pedra:

— Parece que você não é o maior lugar do universo.

A Pedra recebeu a notícia com muita firmeza.

## Capítulo 2 — O restinho da cauda

Froguinho estava olhando para trás.

Virava para a esquerda.

Virava para a direita.

Parecia uma bússola com cócegas.

— Perdeu alguma coisa? — perguntou {nome}.

— Quase. Minha cauda está indo embora sem preencher o formulário.

— Seu corpo está absorvendo a cauda, lembra?

— Lembro. Mas achei que ela mandaria um cartão.

{nome} pegou o caderno onde anotava as mudanças do amigo.

Havia um desenho de quando ele era girino: cabeça redonda e cauda enorme.

No desenho seguinte, apareceram as patas traseiras.

Depois, as quatro patas.

E agora seria preciso desenhar a estreia na Pedra.

— Olha quanta coisa você aprendeu a fazer — disse {nome}.

Froguinho examinou os desenhos.

— No primeiro eu pareço uma vírgula.

— Era sua cauda.

— Uma vírgula muito elegante.

{nome} desenhou o sapinho sobre a pedra e escreveu: “Hoje ele subiu sozinho”.

Froguinho ficou olhando aquela frase.

Sozinho.

Ele tinha recebido cuidado enquanto mudava. Agora começava a fazer coisas que antes não conseguia.

— Você reparou em tudo isso? — perguntou.

— Em quase tudo.

— Reparou quando escorreguei?

— Sim.

— Apague essa parte. Foi uma dança.

{nome} desenhou uma pequena estrela ao lado da anotação.

A dança ficou sem estrela.

Por decisão do artista.

## Capítulo 3 — A encomenda impossível

Naquela tarde, Froguinho fez um pedido.

— Preciso de uma folha.

— Para quê?

— Para observar a sombra dela.

{nome} achou curioso.

— Só isso?

— E um galho. E umas plantas. E um lugar úmido para me esconder. E insetos que passem por perto.

Fez uma pausa.

— E uma noite inteira com barulhos.

— Uma noite inteira?

— Pode embrulhar para presente.

{nome} imaginou colocar a noite numa caixa.

As estrelas ficariam todas amassadas.

— Acho que não cabe.

Froguinho olhou o espaço ao redor.

— Talvez caiba uma noite pequena.

Os dois riram.

Então {nome} percebeu uma coisa: o amigo não estava pedindo mais brinquedos. Estava curioso sobre esconderijos, cheiros, comida e sons.

Coisas que faziam parte da vida de um sapo.

A Pedra tinha sido muito importante. A parte fora da água ajudara Froguinho durante sua transformação.

Mas uma pedra não era uma paisagem inteira.

— Posso desenhar a noite — sugeriu {nome}.

— Ótimo. Não esqueça os mosquitos.

— Quantos?

— Uns oitocentos.

— Não vou desenhar oitocentos mosquitos!

— Tudo bem. Setecentos e noventa e nove.

{nome} desenhou três.

Froguinho chamou aquilo de “amostra grátis”.

## Capítulo 4 — O Grande Prêmio da Pedra

Naquela noite, {nome} sonhou com uma pista de corrida.

Uma folha anunciava:

**GRANDE PRÊMIO DOS ANFÍBIOS — EDIÇÃO PEDRA**

O narrador era um grilo de gravata.

— Senhoras, senhores e coisas que parecem gravetos: vamos começar!

Froguinho se posicionou na largada.

Ao lado dele estava a Pedra.

— Ela também vai correr? — perguntou {nome}.

— É a campeã de ficar onde está — explicou o grilo.

— PREPARAR… APONTAR… JÁ!

Froguinho saltou.

PLOC!

A Pedra ficou.

— Incrível concentração da competidora Pedra! — gritou o narrador.

Froguinho deu outro salto e chegou ao fim da pista.

A pista era muito curta.

— Acabou?

— Acabou — disse o grilo.

— Mas eu só comecei.

No sonho, {nome} olhou além da chegada. Havia folhas, sombras, chão úmido e caminhos tortinhos.

Nenhuma arquibancada.

Nenhum troféu.

Mesmo assim, Froguinho parecia interessado.

— Lá fora não tem corrida organizada — disse o grilo. — Tem vida de sapo.

— Com intervalo para ficar parado?

— Muitos.

Froguinho sorriu.

A Pedra ganhou o prêmio de melhor permanência.

{nome} acordou rindo.

Mas a pergunta do sonho ficou passeando pela cabeça:

E se o fim daquela pista fosse o começo de outro caminho?

## Capítulo 5 — Um mapa que não cabe

No dia seguinte, {nome} abriu o caderno numa página limpa.

— Vou desenhar o mundo de um sapo.

Froguinho aprovou.

— Comece pelo restaurante.

— Você quer dizer os insetos?

— Prefiro “restaurante que passa voando”.

No desenho apareceram plantas, abrigo entre folhas e um cantinho úmido.

Depois, outros animais.

Um pássaro.

Um besouro.

Outro sapo.

— Esse sapo parece uma batata — comentou Froguinho.

{nome} acrescentou olhos.

— Agora parece uma batata preocupada.

Enquanto desenhava, {nome} conversou com uma pessoa adulta da família.

Descobriu que cada espécie precisa de um ambiente adequado. Nem todo sapo vive do mesmo jeito. Nem toda lagoa é o lugar certo para qualquer sapo.

— Então não basta um lugar com água? — perguntou.

— Isso. Precisamos conhecer o animal e suas necessidades.

Froguinho olhou o mapa.

Havia tanta coisa naquela página que as folhas começaram a sair pelas bordas.

— Seu desenho está escapando.

{nome} pegou outra folha de papel.

E outra.

O mapa ficou grande.

Grande demais para o recipiente do Froguinho.

Ninguém precisou dizer isso em voz alta.

Froguinho apontou para o desenho do besouro.

— Esse restaurante está andando para longe.

## Capítulo 6 — A reunião dos nomes compridos

Naquela noite, o sonho voltou.

Desta vez, havia uma reunião do Clube dos Anfíbios.

A presidente era uma rã com uma folha na cabeça.

— Declaro aberta a reunião extraordinária de assuntos extraordinariamente extraordinários!

— Ela recebe por palavra? — cochichou Froguinho.

{nome} tentou segurar a risada.

Uma perereca levantou um dedo.

— Hoje vamos falar de animais silvestres.

Froguinho levantou a pata.

— Silvestre é meu sobrenome?

— Não. É uma maneira de falar dos animais que pertencem à vida na natureza — explicou a perereca.

— Froguinho Silvestre soa importante.

A presidente continuou:

— Um sapo pode receber ajuda quando precisa. Mas continua tendo necessidades de sapo.

— Mesmo se ganhar um nome? — perguntou {nome}.

— Mesmo assim.

— E uma pedra particular? — perguntou Froguinho.

— Também.

{nome} pensou nisso.

Dar um nome tornava o amigo especial para alguém.

Não mudava o tipo de animal que ele era.

A perereca desceu da folha.

— Cuidar bem também é descobrir de que vida o outro precisa.

Froguinho ficou pensativo.

— Minha vida precisa de sobrenome?

— Não.

— Ainda bem. Não tenho bolso para guardar documento.

A presidente bateu numa folha para encerrar a reunião.

A folha dobrou.

Precisaram encerrar com um “coax”.

## Capítulo 7 — O Hotel dos Girinos

De manhã, {nome} olhou o cantinho do Froguinho de um jeito novo.

Ali, o amigo tinha sido observado com atenção.

Tinha recebido cuidado durante uma transformação enorme.

Tinha encontrado uma pedra acessível quando seu corpo começou a usar mais o ar.

— Você acha que aqui parece um hotel? — perguntou {nome}.

Froguinho examinou a acomodação.

— Um hotel com piscina e uma única poltrona de pedra.

— Você gostou daqui?

— Gostei de ter ajuda.

Froguinho fez uma pausa.

— Principalmente quando eu não sabia nem onde colocar as patas.

{nome} sorriu.

Um hotel podia ser importante numa viagem.

Sem precisar ser o lugar onde a viagem terminava.

— Então este podia se chamar Hotel dos Girinos.

— Com café da manhã?

— Froguinho…

— E serviço de despertar? Um grilo gritando “CRI-CRI, SENHOR HÓSPEDE”?

Os dois riram.

Depois, {nome} ficou em silêncio.

A ideia de que o amigo talvez não ficasse ali para sempre apertava um pouquinho por dentro.

Froguinho não fez piada com isso.

Ficou perto.

Às vezes, ficar perto e quietinho também era um jeito de conversar.

A Pedra entendeu perfeitamente.

Tinha muita experiência no assunto.

## Capítulo 8 — O bolso para guardar saudade

{nome} abriu o caderno.

Olhou a vírgula que tinha sido girino.

Olhou as primeiras patas.

Olhou a estrela ao lado do primeiro salto.

— Se você for conhecer o mundo lá fora… eu vou sentir sua falta.

Froguinho respirou devagar.

— Acho que eu também sentiria falta do gigante que conversa com a água.

— Eu conversava com você!

— Para quem passava na porta, era com a água.

{nome} riu um pouquinho.

Depois suspirou.

— Dá para ficar feliz e triste ao mesmo tempo?

— Deve dar. Eu fiquei feliz quando ganhei patas e triste quando descobri que eram quatro para coordenar.

{nome} passou o dedo pela borda do caderno.

Ali cabiam desenhos, lembranças e histórias.

Não era preciso guardar o sapo para guardar o que tinham vivido.

Essa ideia não fez a saudade desaparecer.

Mas deu a ela um lugar macio para sentar.

— Vou chamar este caderno de Bolso de Aventuras.

Froguinho olhou para si mesmo.

— Continuo sem bolso.

— Você pode ter um bolso imaginário.

— Cabe uma mosca?

— Imaginária.

Froguinho fingiu mastigar.

— Crocante.

{nome} desenhou um bolso minúsculo no sapinho do caderno.

Dentro dele, colocou uma estrela.

## Capítulo 9 — O Departamento do Calma Lá

Froguinho deu um saltinho.

{nome} pensou no mapa enorme.

Pensou no hotel.

Pensou na vida que o amigo estava começando a conseguir viver.

Então chamou uma pessoa adulta da família.

— Como vamos saber se ele já pode voltar para a natureza?

— Vamos pedir orientação a quem trabalha com animais silvestres.

Froguinho arregalou os olhos.

— Existe um Departamento do Calma Lá?

— Mais ou menos — respondeu {nome}.

Na história, a família procurou uma equipe que entendia desses animais.

Contou onde o girino tinha sido encontrado e como fora cuidado. Mostrou as mudanças, explicou o salto e perguntou o que fazer.

A equipe explicou que subir na pedra era uma mudança importante.

Mas um salto, sozinho, não respondia a todas as perguntas.

Era preciso considerar a espécie, a saúde, a origem e o ambiente adequado.

— Então não é uma corrida para sair hoje — disse {nome}.

— Isso. É uma decisão cuidadosa.

Froguinho concordou.

— Aprovo o Departamento do Calma Lá.

Fez uma pausa.

— Desde que não peçam para a Pedra preencher formulário.

— Por quê?

— Ela tem letra péssima.

{nome} voltou ao caderno e escreveu uma pergunta nova.

Às vezes, o próximo passo de um explorador era pedir ajuda.

## Capítulo 10 — A mala de um sapo

Depois das conversas com a equipe, a família começou a se preparar, seguindo a orientação recebida.

Froguinho anunciou:

— Vou arrumar minha mala.

{nome} levantou uma sobrancelha.

— Que mala?

— Minha mala invisível.

— O que vai levar?

Froguinho pensou.

— Quatro patas. Dois olhos. Uma vontade de investigar aquela sombra ali.

— Só?

— Talvez a Pedra.

Os dois olharam para ela.

Depois olharam para Froguinho.

A Pedra era enorme perto dele.

— Acho que excede o limite de bagagem — disse {nome}.

Froguinho suspirou.

— Ela vai ter que viajar na imaginação.

{nome} entendeu outra coisa: o amigo não precisava levar os objetos do quarto para continuar sendo o mesmo sapinho.

Precisava das condições certas para viver como sapo.

Enquanto esperavam o momento indicado, o cuidado continuava.

Ninguém soltou Froguinho às pressas.

Ninguém escolheu uma lagoa só porque era bonita.

{nome} desenhou uma mala no caderno.

Dentro, colocou quatro patas e uma pedra com asas.

— Ficou bom? — perguntou.

— Ficou. Mas agora a Pedra quer passagem na janela.

A mala imaginária precisou aumentar.

Só um pouquinho.

## Capítulo 11 — O Grande Prêmio do Mundo Lá Fora

Naquela noite, o grilo narrador voltou ao sonho.

Sua gravata estava torta.

A placa, enorme:

**GRANDE PRÊMIO DOS ANFÍBIOS — MUNDO LÁ FORA**

— Onde está a linha de chegada? — perguntou {nome}.

— Este ano mudamos o regulamento — disse o grilo. — Não ganha quem chega primeiro.

Froguinho levantou a pata.

— Finalmente um esporte que respeita minhas pausas.

O narrador mostrou três provas.

A primeira se chamava Encontrar um Cantinho Adequado.

A segunda, Seguir Seu Próprio Caminho.

A terceira, Ser Sapo Sem Precisar Dar Entrevista.

— Difícil essa última — comentou a perereca.

{nome} estava na torcida.

Quase gritou “Vai por ali!”.

Mas percebeu que, naquele sonho, não precisava escolher cada salto do Froguinho.

Podia torcer sem pilotar o amigo como um carrinho de controle remoto.

Froguinho olhou para um abrigo entre folhas.

Parou.

Observou.

E escolheu um caminho.

O grilo cochichou:

— Às vezes, a melhor torcida faz silêncio.

A Pedra recebeu uma medalha honorária.

Categoria: “Ajudou alguém a começar”.

{nome} acordou com vontade de desenhar aquela medalha.

Não havia perdedores naquele prêmio.

Nem cronômetro.

O grilo tinha comido o papel dos horários.

## Capítulo 12 — Um combinado bem pequeno

Chegou a orientação que a família esperava.

Naquela história, a equipe avaliou as informações e indicou como, quando e onde o retorno de Froguinho poderia acontecer.

{nome} ouviu junto.

Não precisava resolver tudo sozinho.

Depois, sentou perto do amigo.

— Acho que sua próxima aventura está chegando.

Froguinho olhou para fora.

— Minha barriga ficou esquisita.

— A minha também.

— Talvez seja coragem se espreguiçando.

{nome} sorriu.

Os dois fizeram um combinado.

Não era “você precisa voltar para me visitar”.

Um sapo teria seus próprios caminhos. Talvez ficasse escondido. Talvez seguisse para um lugar onde ninguém conseguisse vê-lo.

O combinado era outro:

{nome} continuaria observando a natureza com cuidado.

E Froguinho poderia continuar sua vida de sapo.

Sem ter que provar amizade aparecendo numa pedra marcada.

— Posso guardar seus desenhos? — perguntou {nome}.

— Pode. Menos aquele em que pareço uma batata.

— Esse era outro sapo.

— Então pode guardar também.

{nome} escreveu no caderno:

“Torcer por um amigo também é querer que ele fique bem.”

Froguinho pediu uma alteração.

— Coloque que a Pedra foi excelente funcionária.

Foi acrescentada uma observação no rodapé.

## Capítulo 13 — O salto que não era adeus

No dia combinado, {nome} foi com a família.

Os adultos seguiram as orientações da equipe para o retorno de Froguinho ao lugar adequado.

Havia cheiro de terra e folhas.

E sons que não precisavam sair de uma caixinha.

{nome} ficou por perto, sem apressar o sapinho.

Froguinho observou.

À frente havia caminhos de verdade.

Não os caminhos desenhados no caderno.

— É grande — cochichou ele.

— É.

— Não cabe embrulhado.

{nome} sentiu um sorriso e um aperto chegando juntos.

— Eu cuidei de você quando era bem pequeno.

— Cuidou — disse Froguinho. — E percebeu quando comecei a mudar.

O sapinho mexeu as patas.

— Obrigado pelo começo.

{nome} queria dizer muitas coisas.

Saiu só uma:

— Boa aventura.

Froguinho saltou.

PLOC.

Parou entre as folhas.

Depois deu outro salto.

Não havia troféu na chegada.

Não havia música de campeonato.

Mas aquele era um salto muito importante.

{nome} ficou observando de longe, sem ir atrás para pegá-lo de novo.

O amigo tinha recebido ajuda para chegar até ali.

Agora havia espaço para continuar.

Uma folha se mexeu.

Talvez fosse Froguinho.

Talvez fosse apenas o vento.

{nome} deixou a folha guardar seu segredo.

## Capítulo 14 — A Pedra aposentada

Quando voltou, {nome} sentiu falta de olhar e encontrar Froguinho.

Isso não significava que o retorno tivesse sido uma escolha ruim.

Significava que a amizade tinha sido importante.

No caderno, desenhou o último salto que tinha visto.

Depois desenhou a Pedra usando chinelos.

Uma pessoa da família olhou.

— A Pedra está de férias?

— Aposentada. Trabalhou muito.

— Fazendo o quê?

— Ficando.

Parecia pouco.

Mas, para um sapinho aprendendo a sair da água, tinha sido muito.

{nome} criou um diploma:

**PEDRA — PRIMEIRO LUGAR EM AJUDAR SEM SAIR DO LUGAR**

Embaixo, escreveu:

“Hotel dos Girinos: uma estadia, muitas descobertas.”

Não era preciso arranjar outro animal para ocupar o espaço.

A próxima aventura podia começar observando uma planta, escutando um pássaro ou desenhando um inseto onde ele vivia.

Sem levá-lo para casa.

{nome} abriu a janela e ouviu o mundo.

Um passarinho cantou.

Um inseto passou.

Nenhum deles tinha marcado reunião.

— O atendimento aqui está muito movimentado — murmurou.

À noite, apareceu uma saudade pequena.

{nome} abriu o Bolso de Aventuras.

A estrela do primeiro salto ainda estava lá.

A Pedra de chinelos também.

As duas ajudaram.

## Capítulo 15 — O campeão que não precisava aparecer

Algum tempo depois, {nome} passeou com a família por um lugar com plantas e sons de bichinhos.

O céu começava a mudar de cor.

De algum canto veio um coaxar.

{nome} parou.

— Froguinho?

Não apareceu nenhum sapo para mostrar documento.

Ainda bem.

Sapos continuavam sem bolsos.

Podia ser Froguinho.

Podia ser outro sapo.

Não era possível saber.

Dessa vez, {nome} percebeu que não precisava encontrar o amigo para que a aventura tivesse valido a pena.

Tinha cuidado.

Tinha observado.

Tinha pedido ajuda.

E, quando o momento foi adequado, tinha ajudado a abrir espaço para uma vida de sapo.

A natureza não era uma prateleira onde guardar Froguinho.

Era um mundo vivo, cheio de outros seres e caminhos próprios.

{nome} deixou cada bichinho em seu caminho e continuou o passeio.

Na cabeça, o grilo de gravata anunciou:

— Resultado do Grande Prêmio dos Anfíbios!

Froguinho: campeão de começar uma nova aventura.

{nome}: campeão de cuidar e aprender.

Pedra: campeã absoluta da categoria Pedra.

— De novo? — perguntou a perereca imaginária.

— Imbatível — respondeu o grilo.

{nome} começou a rir.

Lá longe, outro coaxar.

Não era uma promessa de visita.

Era só um pedacinho do mundo seguindo vivo.

E isso também era bonito.

**FIM.**

Ou, no idioma oficial do campeonato:

**PLOC… COAX!**
